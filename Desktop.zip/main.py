import time
import math
import cv2
import win32api
import win32con
import win32gui
import threading
import numpy as np
from pynput.mouse import Controller, Button

from wnd_cap import capture
from GDI import GDIDraw

class WndCap(threading.Thread):
    def __init__(self, hwnd):
        threading.Thread.__init__(self)
        self.on = True
        self.hwnd = hwnd
        self.img = None 

    def run(self):
        while self.on:
            self.img = cv2.cvtColor(capture(self.hwnd), cv2.COLOR_RGBA2RGB)

    def terminate(self):
        self.on = False

class Vec2:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.h = math.hypot(x, y)

    @property
    def value(self):
        return self.x, self.y

    @property
    def unite(self):
        if self.h == 0:
            return Vec2(0, 0)
        return Vec2(self.x/self.h, self.y/self.h)

    @property
    def tan(self):
        if self.y == 0:
            return 0
        return self.x/self.y

    def dot(self, n):
            return Vec2(self.x * n, self.y * n)

    def __add__(self, v):
        return Vec2(self.x + v.x, self.y + v.y)
     
    def __sub__(self, v):
        return Vec2(self.x - v.x, self.y - v.y)

    def __mul__(self, v):
        return Vec2(self.x * v.x, self.y * v.y)
    
    def __str__(self):
        return '(%f - %f)'%(self.x, self.y)     

def find_color_contours(img, lower, upper):
    kernel0 = np.ones((4,4), np.uint8)
    kernel1 = np.ones((20,20), np.uint8)
    mask = cv2.inRange(img, lower, upper)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel0)
    mask = cv2.dilate(mask, kernel1, iterations = 1)
    ret = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    return ret[0] if len(ret) == 2 else ret[1]
    
def find_enemies(img):
    enemies = []
    l = np.array([0, 2, 47])
    u = np.array([0, 11, 90])
    offsetx, offsety = 40, 57
    for cnt in find_color_contours(img, l, u):
        approx = cv2.approxPolyDP(cnt, 0.1*cv2.arcLength(cnt, True), True)
        if approx.size <= 12:
            x, y, w, h = cv2.boundingRect(approx)
            e = Vec2(x + w + offsetx, y + h + offsety)
            enemies.append(e)
    return enemies

def min_entity(entities):
    md = math.inf
    me = None
    m = Vec2(*mouse.position)
    for e in entities:
        d = (e-m).h
        if d < md:
            md = d
            me = e
    return me

def local_player(img):
    l = np.array([35, 25, 0])
    u = np.array([49, 35, 4])
    offsetx, offsety = 38, 60
    for cnt in find_color_contours(img, l, u):
        approx = cv2.approxPolyDP(cnt, 0.1*cv2.arcLength(cnt, True), True)
        if approx.size == 8:
            x, y, w, h = cv2.boundingRect(approx)
            _x, _y = (x + w, y + h)
            if np.array_equal(img[_y-22][_x-2], [33, 138, 49]):
                return Vec2(_x + offsetx, _y + offsety)
                
def predict(dt=0.5, st=1):
    e0 = min_entity(find_enemies(cap.img))
    time.sleep(dt) 
    e1 = min_entity(find_enemies(cap.img))
    if not e0 or e1:
        return None
    e0, e1 = Vec2(*e0), Vec2(*e1)    
    r = e1 + de.unite.dot(st)
    return int(r.x), int(r.y)


## simple evader
def evade(p0, p1, a):
    vec_d = p1-p0 
    de = math.tan(a)*vec_d.h
    b = math.radians(180) - math.atan(vec_d.tan)        
    dy = de*math.sin(b)
    dx = de*math.cos(b)
    v = Vec2(dx,dy)
    return p1 + v

   
                 
if __name__ == '__main__':
    mouse = Controller()
    
    gdi = GDIDraw()

    print('[@] League-of-Legends Skill-Shot AimBot')
        
    hwnd = win32gui.FindWindow(0, 'League of Legends (TM) Client')

    if not hwnd:
        print('[!] Game not found')
        quit()

    cap = WndCap(hwnd)
    cap.setDaemon(True)
    cap.start()

    alpha = 30

    print('evade degree: ', alpha)
    
    while not win32api.GetAsyncKeyState(win32con.VK_HOME):            
        if not cap.img is None:
        
            e = min_entity(find_enemies(cap.img))
            p = local_player(cap.img)

            if e:
                gdi.circle(e.value, 30, 2, (255,0,255))
            
            if p and e:    
                eva = evade(e, p, math.radians(alpha))
                gdi.line(p.value, (int(eva.value[0]), int(eva.value[1])),2,(255,255,0))

                eva = evade(e, p, -math.radians(alpha))
                gdi.line(p.value, (int(eva.value[0]), int(eva.value[1])),2,(0,255,255))
                
                gdi.line(p.value, e.value, 2, (255,255,255))
                if win32api.GetAsyncKeyState(0x4C):
                    mouse.position = int(eva.value[0]),int(eva.value[1])
        
            if win32api.GetAsyncKeyState(0x51) or\
                win32api.GetAsyncKeyState(0x57) or\
                win32api.GetAsyncKeyState(0x52):

                #e = min_entity(find_enemies(cap.img))
                #p = local_player(cap.img)
                if e:
                    mouse.position = e.value
    cap.terminate()
